package edu.utdallas.taskExecutor;


public interface Task
{
	void execute();

	String getName();
}