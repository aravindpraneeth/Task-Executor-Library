package edu.utdallas.taskExecutor;

public interface TaskExecutor {
	public void addTask(Task task);

}
